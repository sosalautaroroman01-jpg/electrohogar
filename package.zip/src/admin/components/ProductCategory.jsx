export default function ProductCategory({
  form,
  setForm,
  categorias,
  handleChange,
}) {
  return (
    <>
      <label>Categoría</label>

      <input
        list="lista-categorias"
        name="categoria"
        placeholder="Escribí o elegí una categoría..."
        value={form.categoria}
        onChange={(e) => {
          const categoria = e.target.value.trim();

          setForm((prev) => ({
            ...prev,
            categoria,

            marca:
              categoria.toLowerCase() === "celulares"
                ? prev.marca
                : "",

            subcategoria:
              categoria.toLowerCase() === "blanquería"
                ? prev.subcategoria
                : "",

            medida:
              categoria.toLowerCase() === "blanquería"
                ? prev.medida
                : "",
          }));
        }}
        autoComplete="off"
        required
      />

      <datalist id="lista-categorias">
        {categorias.map((categoria) => (
          <option
            key={categoria}
            value={categoria}
          />
        ))}
      </datalist>

      {form.categoria === "Celulares" && (
        <>
          <label>📱 Marca</label>

          <select
            name="marca"
            value={form.marca}
            onChange={handleChange}
            required
          >
            <option value="">
              Seleccionar marca...
            </option>
            <option value="Samsung">
              Samsung
            </option>
            <option value="Motorola">
              Motorola
            </option>
            <option value="iPhone">
              iPhone
            </option>
            <option value="Xiaomi">
              Xiaomi
            </option>
          </select>
        </>
      )}

      {form.categoria === "Blanquería" && (
        <>
          <label>🛏️ Subcategoría</label>

          <select
            name="subcategoria"
            value={form.subcategoria}
            onChange={handleChange}
            required
          >
            <option value="">
              Seleccionar...
            </option>

            <option value="Sábanas">
              🛏️ Sábanas
            </option>

            <option value="Almohadas">
              🛌 Almohadas
            </option>

            <option value="Frazadas">
              🛏️ Frazadas
            </option>

            <option value="Acolchados">
              🛏️ Acolchados
            </option>

            <option value="Alfombras y Cortinas">
              🪟 Alfombras y Cortinas
            </option>

            <option value="Toallas">
              🛁 Toallas
            </option>
          </select>
        </>
      )}

      {["Sábanas", "Frazadas", "Acolchados"].includes(
        form.subcategoria
      ) && (
        <>
          <label>📏 Medida</label>

          <select
            name="medida"
            value={form.medida}
            onChange={handleChange}
            required
          >
            <option value="">
              Seleccionar medida...
            </option>

            <option value="1½ Plaza">
              1½ Plaza
            </option>

            <option value="2½ Plazas">
              2½ Plazas
            </option>

            <option value="King">
              King
            </option>
          </select>
        </>
      )}
    </>
  );
}