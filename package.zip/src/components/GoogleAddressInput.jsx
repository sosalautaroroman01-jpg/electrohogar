import { useEffect, useRef } from "react";
import { cargarGoogleMaps } from "../services/mapsService";

export default function GoogleAddressInput({ onPlaceSelect }) {
  const containerRef = useRef(null);

  useEffect(() => {
    async function iniciar() {
      await cargarGoogleMaps();

      const { PlaceAutocompleteElement } =
        await google.maps.importLibrary("places");

      const autocomplete = new PlaceAutocompleteElement({
        componentRestrictions: {
          country: "ar",
        },
      });

      autocomplete.placeholder = "📍 Escribí la dirección...";

      autocomplete.addEventListener(
        "gmp-select",
        async ({ placePrediction }) => {
          const place = placePrediction.toPlace();

          await place.fetchFields({
            fields: [
              "formattedAddress",
              "location",
            ],
          });

          console.log("PLACE:", place);
          console.log("LOCATION:", place.location);

          onPlaceSelect({
            formatted_address: place.formattedAddress,
            geometry: {
              location: place.location,
            },
          });
        }
      );

      containerRef.current.innerHTML = "";
      containerRef.current.appendChild(autocomplete);
    }

    iniciar();
  }, [onPlaceSelect]);

  return <div ref={containerRef}></div>;
}