import "./InfoBar.css";

function InfoBar() {
  return (
    <div className="info-bar">

      <div className="info-item">
        <span className="info-icon">📦</span>
        <span>+600 Productos</span>
      </div>

      <span className="divider">•</span>

      <div className="info-item">
        <span className="info-icon">🚚</span>
        <span>Envíos a todo el país</span>
      </div>

      <span className="divider">•</span>

      <div className="info-item">
        <span className="info-icon">🏪</span>
        <span>Mayorista y Minorista</span>
      </div>

      <span className="divider">•</span>

      <div className="info-item">
        <span className="info-icon">💵</span>
        <span>Efectivo · Transferencia · USD</span>
      </div>

    </div>
  );
}

export default InfoBar;