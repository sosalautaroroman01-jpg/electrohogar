import { useEffect, useState } from "react";
import { calcularRuta } from "../services/mapsService";

const TARIFAS = {
  moto: 900,
  camioneta: 1500,
};

export default function ResultadoEnvio({
  direccion,
  vehiculo,
}) {
  const [cargando, setCargando] = useState(false);
  const [resultado, setResultado] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    async function calcular() {
      if (!direccion?.geometry) {
        setResultado(null);
        return;
      }

      try {
        setCargando(true);
        setError("");

        const datos = await calcularRuta(
          direccion.geometry.location
        );

        setResultado(datos);
      } catch (err) {
        console.error(err);
        setError("No se pudo calcular el recorrido.");
      } finally {
        setCargando(false);
      }
    }

    calcular();
  }, [direccion]);

  if (!direccion)
    return (
      <p
        style={{
          marginTop: 25,
          color: "#666",
        }}
      >
        Elegí una dirección para calcular el envío.
      </p>
    );

  if (cargando)
    return (
      <h3
        style={{
          marginTop: 25,
        }}
      >
        Calculando recorrido...
      </h3>
    );

  if (error)
    return (
      <p
        style={{
          color: "red",
          marginTop: 25,
        }}
      >
        {error}
      </p>
    );

  if (!resultado) return null;

  const costo = Math.round(
    resultado.distanciaKm * TARIFAS[vehiculo]
  );

  return (
    <div
      style={{
        marginTop: 30,
        padding: 20,
        borderRadius: 16,
        background: "#f8fafc",
        border: "1px solid #ddd",
      }}
    >
      <h2>🚚 Resultado</h2>

      <p>
        <strong>📏 Distancia:</strong>{" "}
        {resultado.distanciaTexto}
      </p>

      <p>
        <strong>⏱ Tiempo:</strong>{" "}
        {resultado.duracion}
      </p>

      <p>
        <strong>
          {vehiculo === "moto"
            ? "🛵 Moto"
            : "🚐 Camioneta"}
        </strong>
      </p>

      <h1
        style={{
          color: "#16a34a",
        }}
      >
        ${costo.toLocaleString("es-AR")}
      </h1>
    </div>
  );
}