import { Link } from "react-router-dom";

import FloatingCart from "../components/FloatingCart";
import AnimatedBackground from "../components/AnimatedBackground";
import Header from "../components/Header";
import SearchBar from "../components/SearchBar";
import Categories from "../components/Categories";
import ProductGrid from "../components/ProductGrid";
import Cart from "../components/Cart";
import DollarTicker from "../components/DollarTicker";
import InfoBar from "../components/InfoBar";

function Home() {
  return (
    <>
      <AnimatedBackground />

      <Cart />
      <FloatingCart />

      <div className="app">
        <DollarTicker />

        <Header />

        <section className="hero">
          <div className="hero-search">
            <SearchBar />
          </div>

          {/* Barra informativa */}
          <InfoBar />

          {/* Botón Calculadora */}
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              margin: "20px 0",
            }}
          >
            <Link
              to="/calculadora-envios"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "10px",
                background: "#16a34a",
                color: "#fff",
                padding: "14px 26px",
                borderRadius: "14px",
                textDecoration: "none",
                fontWeight: "700",
                fontSize: "16px",
                boxShadow: "0 10px 25px rgba(22,163,74,.30)",
                transition: ".25s",
              }}
            >
              🧮 Calcular costo de envío
            </Link>
          </div>

          <div className="hero-categories">
            <Categories />
          </div>
        </section>

        <ProductGrid />
      </div>
    </>
  );
}

export default Home;