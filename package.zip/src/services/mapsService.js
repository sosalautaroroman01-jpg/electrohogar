import { setOptions, importLibrary } from "@googlemaps/js-api-loader";

setOptions({
  key: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
  version: "weekly",
});

let mapsLib = null;

export async function cargarGoogleMaps() {
  if (mapsLib) return mapsLib;

  await importLibrary("maps");
  await importLibrary("places");

  mapsLib = window.google.maps;

  return mapsLib;
}

const ORIGEN = {
  lat: -34.746819,
  lng: -58.2792843,
};

export async function calcularRuta(destino) {
  await cargarGoogleMaps();

  const service = new google.maps.DirectionsService();

  return new Promise((resolve, reject) => {
    service.route(
      {
        origin: ORIGEN,
        destination: destino,
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status !== "OK") {
          reject(status);
          return;
        }

        const leg = result.routes[0].legs[0];

        resolve({
          distanciaKm: leg.distance.value / 1000,
          distanciaTexto: leg.distance.text,
          duracion: leg.duration.text,
        });
      }
    );
  });
}