import { useEffect, useState } from "react";
import { obtenerProductos } from "../../services/productosService";
import "../../styles/forms.css";

const EMPTY_FORM = {
  nombre: "",
  categoria: "",
  marca: "",
  moneda: "ARS",
  precio: "",
  precio2: "",
  precio3: "",
  precio6: "",
  precio9: "",
  precio12: "",
  stock: "",
  descripcion: "",
  imagen: "",
  imagenes: [],
  video: "",
  videoFile: null,
  visible: true,
};

export default function ProductForm({
  initialData,
  onSubmit,
  textoBoton = "Guardar Producto",
}) {
  const [form, setForm] = useState(initialData || EMPTY_FORM);

  const [preview, setPreview] = useState([]);

  const [categorias, setCategorias] = useState([]);

  useEffect(() => {
    if (initialData) {
      setForm({
        ...EMPTY_FORM,
        ...initialData,
      });

      if (initialData.imagenes?.length > 0) {
        setPreview(initialData.imagenes);
      } else if (initialData.imagen) {
        setPreview([initialData.imagen]);
      }
    }
  }, [initialData]);
useEffect(() => {
  async function cargarCategorias() {
    const productos = await obtenerProductos();

    console.log("PRODUCTOS:", productos);

    const lista = [
      ...new Set(
        productos
          .map((p) => (p.categoria || "").trim())
          .filter((c) => c !== "")
      ),
    ].sort();

    console.log("CATEGORIAS:", lista);

    setCategorias(lista);
  }

  cargarCategorias();
}, []);

function handleChange(e) {
  setForm({
    ...form,
    [e.target.name]: e.target.value,
  });
}

function handleImagen(e) {
  const files = Array.from(e.target.files);

  if (!files.length) return;

  setForm((prev) => ({
    ...prev,
    imagenesFile: [
      ...(prev.imagenesFile || []),
      ...files,
    ],
  }));

  setPreview((prev) => [
    ...prev,
    ...files.map((file) => URL.createObjectURL(file)),
  ]);

  // Permite volver a seleccionar el mismo archivo
  e.target.value = "";
}

function handleVideo(e) {
  const file = e.target.files[0];

  if (!file) return;

  setForm((prev) => ({
    ...prev,
    videoFile: file,
  }));

  e.target.value = "";
}

function eliminarImagen(index) {
  // Elimina la imagen de la vista previa
  setPreview((prev) => prev.filter((_, i) => i !== index));

  // Elimina también del estado del formulario
  setForm((prev) => {
    const imagenes = [...(prev.imagenes || [])];
    const imagenesFile = [...(prev.imagenesFile || [])];

    // Si es una imagen ya guardada
    if (index < imagenes.length) {
      imagenes.splice(index, 1);
    } else {
      // Si es una imagen agregada en esta edición
      imagenesFile.splice(index - imagenes.length, 1);
    }

    return {
      ...prev,
      imagenes,
      imagenesFile,
    };
  });
}

  function handleSubmit(e) {
    e.preventDefault();

    onSubmit({
  ...form,

  moneda: form.moneda,

  precio: Number(form.precio),

      precio2:
        form.precio2 === ""
          ? ""
          : Number(form.precio2),

      precio3:
        form.precio3 === ""
          ? ""
          : Number(form.precio3),

      precio6:
        form.precio6 === ""
          ? ""
          : Number(form.precio6),

      precio9:
        form.precio9 === ""
          ? ""
          : Number(form.precio9),

      precio12:
        form.precio12 === ""
          ? ""
          : Number(form.precio12),

      stock:
        form.stock === ""
          ? ""
          : Number(form.stock),
    });
  }

  return (
    <form className="product-form" onSubmit={handleSubmit}>

      <h2>📦 Datos del Producto</h2>

<label>📷 Imágenes (hasta 5)</label>

<input
  type="file"
  accept="image/*"
  multiple
  onChange={handleImagen}
/>

<label style={{ marginTop: 15 }}>
  🎥 Video del producto
</label>

<input
  type="file"
  accept="video/*"
  onChange={handleVideo}
/>

      {preview.length > 0 && (
        
  <div
    style={{
      display: "flex",
      gap: "12px",
      flexWrap: "wrap",
      marginBottom: "20px",
    }}
    
    
  >
    {preview.map((img, index) => (
      <div
        key={index}
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <img
          src={img}
          alt=""
          className="preview-image"
        />

        <button
          type="button"
          onClick={() => eliminarImagen(index)}
          style={{
            marginTop: "6px",
            background: "#dc3545",
            color: "#fff",
            border: "none",
            padding: "6px 10px",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          🗑 Eliminar
        </button>
      </div>
    ))}
  </div>
)}
{form.videoFile && (
  <div
    style={{
      marginBottom: "20px",
    }}
  >
    <video
      controls
      width="250"
      src={URL.createObjectURL(form.videoFile)}
      style={{
        borderRadius: "10px",
      }}
    />

    <br />

    <button
      type="button"
      onClick={() =>
        setForm((prev) => ({
          ...prev,
          videoFile: null,
        }))
      }
      style={{
        marginTop: "8px",
        background: "#dc3545",
        color: "#fff",
        border: "none",
        padding: "6px 12px",
        borderRadius: "6px",
        cursor: "pointer",
      }}
    >
      🗑 Eliminar video
    </button>
  </div>
)}

{form.video && !form.videoFile && (
  <div
    style={{
      marginBottom: "20px",
    }}
  >
    <video
      controls
      width="250"
      src={form.video}
      style={{
        borderRadius: "10px",
      }}
    />
  </div>
)}

      <label>Nombre</label>

      <input
        name="nombre"
        placeholder="Ej: Smart TV TCL 50"
        value={form.nombre}
        onChange={handleChange}
        required
      />

<label>Categoría</label>

<input
  list="lista-categorias"
  name="categoria"
  placeholder="Escribí o elegí una categoría..."
  value={form.categoria}
  onChange={(e) =>
    setForm({
      ...form,
      categoria: e.target.value.trim(),
      marca:
        e.target.value.trim().toLowerCase() === "celulares"
          ? form.marca
          : "",
    })
  }
  autoComplete="off"
  required
/>

<datalist id="lista-categorias">
  {categorias.map((categoria) => (
    <option
      key={categoria}
      value={categoria}
    />
  ))}
</datalist>

{/* Marca (solo para Celulares) */}

{form.categoria.trim().toLowerCase() === "celulares" && (
  <>
    <label>📱 Marca</label>

    <select
      name="marca"
      value={form.marca}
      onChange={handleChange}
      required
    >
      <option value="">Seleccionar marca...</option>
      <option value="Samsung">Samsung</option>
      <option value="Motorola">Motorola</option>
      <option value="iPhone">iPhone</option>
      <option value="Xiaomi">Xiaomi</option>
    </select>
  </>
)}

<label>💵 Moneda</label>

<select
  name="moneda"
  value={form.moneda}
  onChange={handleChange}
>
  <option value="ARS">🇦🇷 Pesos (ARS)</option>
  <option value="USD">🇺🇸 Dólares (USD)</option>
</select>
      <label>💰 Precio Unitario</label>

      <input
        type="number"
        name="precio"
        value={form.precio}
        onChange={handleChange}
        required
      />

      <label>🔥 Precio x2</label>

      <input
        type="number"
        name="precio2"
        value={form.precio2}
        onChange={handleChange}
      />

      <label>🔥 Precio x3</label>

      <input
        type="number"
        name="precio3"
        value={form.precio3}
        onChange={handleChange}
      />

      <label>🔥 Precio x6</label>

      <input
        type="number"
        name="precio6"
        value={form.precio6}
        onChange={handleChange}
      />

      <label>🔥 Precio x9</label>

      <input
        type="number"
        name="precio9"
        value={form.precio9}
        onChange={handleChange}
      />

      <label>🔥 Precio x12</label>

      <input
        type="number"
        name="precio12"
        value={form.precio12}
        onChange={handleChange}
      />

      <label>👁 Estado</label>

      <select
        name="visible"
        value={String(form.visible)}
        onChange={(e) =>
          setForm({
            ...form,
            visible: e.target.value === "true",
          })
        }
      >
        <option value="true">🟢 Visible</option>
        <option value="false">🔴 Oculto</option>
      </select>

      <label>Descripción</label>

      <textarea
        rows="5"
        name="descripcion"
        value={form.descripcion}
        onChange={handleChange}
      />

      <button type="submit">
        💾 {textoBoton}
      </button>

    </form>
  );
}