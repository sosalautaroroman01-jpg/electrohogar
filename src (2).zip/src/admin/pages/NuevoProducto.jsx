import { useNavigate } from "react-router-dom";

import Layout from "../components/Layout";
import ProductForm from "../components/ProductForm";

import { crearProducto } from "../../services/productosService";
import {
  subirImagen,
  subirImagenes,
  subirVideo,
} from "../../services/storageService";

export default function NuevoProducto() {
  const navigate = useNavigate();

  async function guardarProducto(data) {
    try {
      let imagen = "";
      let imagenes = [];
      let video = "";

      // ✅ Varias imágenes
      if (data.imagenesFile?.length) {
        imagenes = await subirImagenes(data.imagenesFile);
        imagen = imagenes[0];
      }

      // Compatibilidad con productos viejos
      else if (data.imagenFile) {
        imagen = await subirImagen(data.imagenFile);
        imagenes = [imagen];
      }

      // ✅ Video
      if (data.videoFile) {
        video = await subirVideo(data.videoFile);
      }

      await crearProducto({
        nombre: data.nombre,

        categoria: data.categoria,

        moneda: data.moneda,

        precio: Number(data.precio),

        precio2:
          data.precio2 === ""
            ? null
            : Number(data.precio2),

        precio3:
          data.precio3 === ""
            ? null
            : Number(data.precio3),

        precio6:
          data.precio6 === ""
            ? null
            : Number(data.precio6),

        precio9:
          data.precio9 === ""
            ? null
            : Number(data.precio9),

        precio12:
          data.precio12 === ""
            ? null
            : Number(data.precio12),

        stock:
          data.stock === ""
            ? null
            : Number(data.stock),

        descripcion: data.descripcion,

        // Compatibilidad
        imagen,

        // Varias imágenes
        imagenes,

        // 🎥 Nuevo
        video,

        visible: data.visible,

        creado: new Date(),
      });

      alert("✅ Producto guardado correctamente");

      navigate("/admin/productos");
    } catch (error) {
      console.error(error);
      alert("❌ Error al guardar el producto");
    }
  }

  return (
    <Layout>
      <h1>➕ Nuevo Producto</h1>

      <ProductForm
        onSubmit={guardarProducto}
        textoBoton="Guardar Producto"
      />
    </Layout>
  );
}