import "./Categories.css";
import { useState } from "react";
import { useFilter } from "../context/FilterContext";

function Categories() {
  const {
    categoria,
    setCategoria,
    busqueda,
    setBusqueda,
    marca,
    setMarca,
  } = useFilter();

  const [mostrarTodas, setMostrarTodas] = useState(false);

  const categorias = [
    "Todas",
    "Smart TV",
    "Celulares",
    "Audio",
    "Entretenimiento",
    "Aires",
    "Heladeras",
    "Freezers",
    "Lavarropas",
    "Cocina",
    "Accesorios de Cocina",
    "Pequeños Electros",
    "Botellas y Térmicos",
    "Belleza y Cuidado",
    "Limpieza",
    "Jardín",
    "Calefacción",
    "Termotanques",
    "Herramientas",
    "Iluminación",
    "Cámaras de Seguridad",
    "Hogar",
  ];

  const principales = [
    "Todas",
    "Smart TV",
    "Celulares",
    "Audio",
    "Aires",
    "Heladeras",
    "Cocina",
    "Herramientas",
  ];

  const iconos = {
    Todas: "🏠",
    "Smart TV": "📺",
    Celulares: "📱",
    Audio: "🔊",
    Entretenimiento: "🎮",
    Aires: "❄️",
    Heladeras: "🧊",
    Freezers: "🥶",
    Lavarropas: "🧺",
    Cocina: "🍳",
    "Accesorios de Cocina": "🍽️",
    "Pequeños Electros": "⚡",
    "Botellas y Térmicos": "🥤",
    "Belleza y Cuidado": "💇",
    Limpieza: "🧹",
    Jardín: "🌿",
    Calefacción: "🔥",
    Termotanques: "🚿",
    Herramientas: "🛠️",
    Iluminación: "💡",
    "Cámaras de Seguridad": "📹",
    Hogar: "🛋️",
  };

  const marcasCelulares = [
    "Todas",
    "Samsung",
    "Motorola",
    "iPhone",
    "Xiaomi",
  ];

  function seleccionarCategoria(cat) {
    setBusqueda("");
    setCategoria(cat);
    setMarca("Todas");
  }

  const lista = mostrarTodas ? categorias : principales;

  return (
    <>
      <div className="categories">

        {lista.map((cat) => (
          <button
            key={cat}
            onClick={() => seleccionarCategoria(cat)}
            className={
              categoria === cat
                ? "category-btn active"
                : "category-btn"
            }
          >
            <span>{iconos[cat]}</span>
            <span>{cat}</span>
          </button>
        ))}

        {!mostrarTodas && (
          <button
            className="category-btn"
            onClick={() => setMostrarTodas(true)}
          >
            ➕ Más
          </button>
        )}

      </div>

      {mostrarTodas && (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            marginTop: "10px",
          }}
        >
          <button
            className="category-btn"
            onClick={() => setMostrarTodas(false)}
          >
            ▲ Mostrar menos
          </button>
        </div>
      )}

      {/* ===== FILTRO DE MARCAS ===== */}

      {categoria === "Celulares" && (
        <div
          className="categories"
          style={{
            marginTop: "14px",
          }}
        >
          {marcasCelulares.map((item) => (
            <button
              key={item}
              onClick={() => setMarca(item)}
              className={
                marca === item
                  ? "category-btn active"
                  : "category-btn"
              }
            >
              {item}
            </button>
          ))}
        </div>
      )}
    </>
  );
}

export default Categories;