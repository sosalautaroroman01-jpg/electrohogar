import "./FloatingCart.css";
import { useCart } from "../context/CartContext";

function FloatingCart() {
  const { carrito, setAbierto } = useCart();

  const cantidad = carrito.reduce(
    (total, item) => total + item.cantidad,
    0
  );

  return (
    <button
      className="floating-cart"
      onClick={() => setAbierto(true)}
    >
      🛒

      {cantidad > 0 && (
        <span className="floating-cart-badge">
          {cantidad}
        </span>
      )}
    </button>
  );
}

export default FloatingCart;