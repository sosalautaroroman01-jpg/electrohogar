import "./Header.css";
import logo from "../assets/logo.png";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function Header() {
  const { usuario, logout } = useAuth();

  return (
    <header className="header">

      <div className="header-user">
        {!usuario ? (
          <Link to="/admin/login" className="user-btn">
            👤
          </Link>
        ) : (
          <div className="admin-menu">
            <button className="user-btn">
              👤
            </button>

            <div className="admin-dropdown">
              <p>{usuario.email}</p>

              <Link className="dropdown-link" to="/admin">
                📊 Panel Admin
              </Link>

              <Link className="dropdown-link" to="/admin/productos">
                📦 Productos
              </Link>

              <button onClick={logout}>
                🚪 Cerrar sesión
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="hero-logo">
        <img
          src={logo}
          alt="Electro Hogar"
          className="logo"
        />
      </div>

      <div className="header-space"></div>

    </header>
  );
}

export default Header;