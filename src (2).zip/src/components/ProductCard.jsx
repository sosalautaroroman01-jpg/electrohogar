import "./ProductCard.css";
import { useState, useEffect } from "react";
import { useCart } from "../context/CartContext";
import { useDollar } from "../context/DollarContext";

function ProductCard({ producto }) {
  const { agregarAlCarrito } = useCart();
  const blue = useDollar();

  const imagenes =
    producto.imagenes?.length > 0
      ? producto.imagenes
      : producto.imagen
      ? [producto.imagen]
      : [];

  const video = producto.video || "";

  const total = imagenes.length + (video ? 1 : 0);

  const [imagenActual, setImagenActual] = useState(0);
  const [imagenAbierta, setImagenAbierta] = useState(false);

  useEffect(() => {
    function manejarTeclas(e) {
      if (!imagenAbierta) return;

      switch (e.key) {
        case "Escape":
          setImagenAbierta(false);
          break;

        case "ArrowRight":
          if (total > 1) {
            setImagenActual((prev) =>
              prev === total - 1 ? 0 : prev + 1
            );
          }
          break;

        case "ArrowLeft":
          if (total > 1) {
            setImagenActual((prev) =>
              prev === 0 ? total - 1 : prev - 1
            );
          }
          break;

        default:
          break;
      }
    }

    window.addEventListener("keydown", manejarTeclas);

    return () => {
      window.removeEventListener(
        "keydown",
        manejarTeclas
      );
    };
  }, [imagenAbierta, total]);

  function siguienteImagen(e) {
    e?.stopPropagation();

    if (total <= 1) return;

    setImagenActual((prev) =>
      prev === total - 1 ? 0 : prev + 1
    );
  }

  function anteriorImagen(e) {
    e?.stopPropagation();

    if (total <= 1) return;

    setImagenActual((prev) =>
      prev === 0 ? total - 1 : prev - 1
    );
  }

  return (
    <>
      <div className="card">

        {(imagenes.length > 0 || video) && (
          <div
            className="image-container"
            style={{
              overflow: "visible",
              paddingLeft: "28px",
              paddingRight: "28px",
            }}
          >
            <div className="image-box">

              {video &&
              imagenActual === imagenes.length ? (
                <video
                  className="card-img"
                  controls
                  playsInline
                >
                  <source
                    src={video}
                    type="video/mp4"
                  />
                </video>
              ) : (
                <img
                  src={imagenes[imagenActual]}
                  alt={producto.nombre}
                  className="card-img"
                  onClick={() =>
                    setImagenAbierta(true)
                  }
                />
              )}

            </div>

            {total > 1 && (
              <>
              <button
                className="image-arrow left"
                onClick={anteriorImagen}
              >
                ❮
              </button>

              <button
                className="image-arrow right"
                onClick={siguienteImagen}
              >
                ❯
              </button>

              <div className="image-counter">
                {imagenActual + 1} / {total}
              </div>

              <div className="thumbnail-strip">
                {imagenes.map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt=""
                    className={
                      imagenActual === index
                        ? "thumbnail active"
                        : "thumbnail"
                    }
                    onClick={() => setImagenActual(index)}
                  />
                ))}

                {video && (
                  <div
                    className={
                      imagenActual === imagenes.length
                        ? "thumbnail active"
                        : "thumbnail"
                    }
                    onClick={() => setImagenActual(imagenes.length)}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "26px",
                      cursor: "pointer",
                    }}
                  >
                    🎥
                  </div>
                )}

</div>
    </>
  )}

</div>

        )}

        <div className="card-body">

          <h3>{producto.nombre}</h3>

  <p className="precio">
    {(producto.moneda || "ARS") === "USD"
      ? `💵 USD ${Number(producto.precio || 0).toLocaleString("es-AR")}`
      : `$${Number(producto.precio || 0).toLocaleString("es-AR")}`}
  </p>

{(producto.moneda || "ARS") === "USD" && blue && (
  <div className="precio-ars">
    🇦🇷 $
    {Math.round(
      Number(producto.precio || 0) * Number(blue.venta)
    ).toLocaleString("es-AR")}
    <span>ARS</span>
  </div>
)}

          {(producto.precio2 ||
  producto.precio3 ||
  producto.precio6 ||
  producto.precio9 ||
  producto.precio12) && (
            <div
  style={{
    marginBottom: "15px",
    background: "#f3fff5",
    border: "1px solid #16a34a",
    borderRadius: "10px",
    padding: "10px",
    fontSize: "14px",
  }}
>
  {producto.precio2 > 0 && (
    <div>
      🔥 <strong>x2:</strong>{" "}
      {(producto.moneda || "ARS") === "USD" ? "USD " : "$"}
      {Number(producto.precio2).toLocaleString("es-AR")}
    </div>
  )}

  {producto.precio3 > 0 && (
    <div>
      🔥 <strong>x3:</strong>{" "}
      {(producto.moneda || "ARS") === "USD" ? "USD " : "$"}
      {Number(producto.precio3).toLocaleString("es-AR")}
    </div>
  )}

  {producto.precio6 > 0 && (
    <div>
      🔥 <strong>x6:</strong>{" "}
      {(producto.moneda || "ARS") === "USD" ? "USD " : "$"}
      {Number(producto.precio6).toLocaleString("es-AR")}
    </div>
  )}

  {producto.precio9 > 0 && (
    <div>
      🔥 <strong>x9:</strong>{" "}
      {(producto.moneda || "ARS") === "USD" ? "USD " : "$"}
      {Number(producto.precio9).toLocaleString("es-AR")}
    </div>
  )}

  {producto.precio12 > 0 && (
    <div>
      🔥 <strong>x12:</strong>{" "}
      {(producto.moneda || "ARS") === "USD" ? "USD " : "$"}
      {Number(producto.precio12).toLocaleString("es-AR")}
    </div>
  )}
</div>
          )}

          <button
  onClick={() =>
    agregarAlCarrito({
      ...producto,
      precio:
        (producto.moneda || "ARS") === "USD"
          ? Math.round(
              Number(producto.precio || 0) * Number(blue.venta)
            )
          : producto.precio,
      precio2:
        (producto.moneda || "ARS") === "USD" && Number(producto.precio2) > 0
          ? Math.round(Number(producto.precio2) * Number(blue.venta))
          : producto.precio2,
      precio3:
        (producto.moneda || "ARS") === "USD" && Number(producto.precio3) > 0
          ? Math.round(Number(producto.precio3) * Number(blue.venta))
          : producto.precio3,
      precio6:
        (producto.moneda || "ARS") === "USD" && Number(producto.precio6) > 0
          ? Math.round(Number(producto.precio6) * Number(blue.venta))
          : producto.precio6,
      precio9:
        (producto.moneda || "ARS") === "USD" && Number(producto.precio9) > 0
          ? Math.round(Number(producto.precio9) * Number(blue.venta))
          : producto.precio9,
      precio12:
        (producto.moneda || "ARS") === "USD" && Number(producto.precio12) > 0
          ? Math.round(Number(producto.precio12) * Number(blue.venta))
          : producto.precio12,
    })
  }
>
  Agregar al carrito
</button>

        </div>

      </div>

      {imagenAbierta && (
  <div
    className="image-modal"
    onClick={() => setImagenAbierta(false)}
  >
    <div
      className="image-modal-content"
      onClick={(e) => e.stopPropagation()}
    >
      <button
        className="close-image"
        onClick={() => setImagenAbierta(false)}
      >
        ✕
      </button>

      {(imagenes.length + (video ? 1 : 0)) > 1 && (
        <button
          className="image-arrow left"
          onClick={anteriorImagen}
        >
          ❮
        </button>
      )}

{video && imagenActual === imagenes.length ? (
  <video
    key="video"
    className="card-img"
    controls
    playsInline
  >
    <source src={video} type="video/mp4" />
  </video>
) : (
  <img
    key={imagenes[imagenActual]}
    src={imagenes[imagenActual]}
    alt={producto.nombre}
    className="image-preview"
  />
)}

      {(imagenes.length + (video ? 1 : 0)) > 1 && (
        <button
          className="image-arrow right"
          onClick={siguienteImagen}
        >
          ❯
        </button>
      )}

      {(imagenes.length + (video ? 1 : 0)) > 1 && (
        <>
          <div className="image-counter">
            {imagenActual + 1} / {total}
          </div>

          <div className="thumbnail-strip">
            {imagenes.map((img, index) => (
              <img
                key={index}
                src={img}
                alt=""
                className={
                  imagenActual === index
                    ? "thumbnail active"
                    : "thumbnail"
                }
                onClick={() => setImagenActual(index)}
              />
            ))}
            {video && (
  <div
    className={
      imagenActual === imagenes.length
        ? "thumbnail active"
        : "thumbnail"
    }
    onClick={() => setImagenActual(imagenes.length)}
    style={{
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: "26px",
      cursor: "pointer",
    }}
  >
    🎥
  </div>
)}
          </div>
        </>
      )}
    </div>
  </div>
)}
    </>
  );
}

export default ProductCard;