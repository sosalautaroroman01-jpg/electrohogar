import { createContext, useContext, useState } from "react";

const FilterContext = createContext();

export function FilterProvider({ children }) {
  const [busqueda, setBusqueda] = useState("");
  const [categoria, setCategoria] = useState("Todas");

  // ✅ Nuevo filtro por marca
  const [marca, setMarca] = useState("Todas");

  return (
    <FilterContext.Provider
      value={{
        busqueda,
        setBusqueda,

        categoria,
        setCategoria,

        marca,
        setMarca,
      }}
    >
      {children}
    </FilterContext.Provider>
  );
}

export function useFilter() {
  return useContext(FilterContext);
}