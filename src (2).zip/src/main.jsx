import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

import { CartProvider } from "./context/CartContext";
import { AuthProvider } from "./context/AuthContext";
import { FilterProvider } from "./context/FilterContext";
import { DollarProvider } from "./context/DollarContext";

createRoot(document.getElementById("root")).render(
  <AuthProvider>
    <DollarProvider>
      <FilterProvider>
        <CartProvider>
          <App />
        </CartProvider>
      </FilterProvider>
    </DollarProvider>
  </AuthProvider>
);