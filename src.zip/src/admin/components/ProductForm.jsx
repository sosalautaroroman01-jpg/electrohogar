import { useEffect, useState } from "react";
import "../../styles/forms.css";

const EMPTY_FORM = {
  nombre: "",
  categoria: "",
  moneda: "ARS",
  precio: "",
  precio2: "",
  precio3: "",
  precio6: "",
  precio9: "",
  precio12: "",
  stock: "",
  descripcion: "",
  imagen: "",
  imagenes: [],
  visible: true,
};

export default function ProductForm({
  initialData,
  onSubmit,
  textoBoton = "Guardar Producto",
}) {
  const [form, setForm] = useState(initialData || EMPTY_FORM);

  const [preview, setPreview] = useState([]);

  useEffect(() => {
    if (initialData) {
      setForm({
        ...EMPTY_FORM,
        ...initialData,
      });

      if (initialData.imagenes?.length > 0) {
        setPreview(initialData.imagenes);
      } else if (initialData.imagen) {
        setPreview([initialData.imagen]);
      }
    }
  }, [initialData]);

  function handleChange(e) {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  }

  function handleImagen(e) {
    const files = Array.from(e.target.files);

    if (!files.length) return;

    setForm({
      ...form,
      imagenesFile: files,
    });

    setPreview(
      files.map((file) => URL.createObjectURL(file))
    );
  }

  function handleSubmit(e) {
    e.preventDefault();

    onSubmit({
  ...form,

  moneda: form.moneda,

  precio: Number(form.precio),

      precio2:
        form.precio2 === ""
          ? ""
          : Number(form.precio2),

      precio3:
        form.precio3 === ""
          ? ""
          : Number(form.precio3),

      precio6:
        form.precio6 === ""
          ? ""
          : Number(form.precio6),

      precio9:
        form.precio9 === ""
          ? ""
          : Number(form.precio9),

      precio12:
        form.precio12 === ""
          ? ""
          : Number(form.precio12),

      stock:
        form.stock === ""
          ? ""
          : Number(form.stock),
    });
  }

  return (
    <form className="product-form" onSubmit={handleSubmit}>

      <h2>📦 Datos del Producto</h2>

      <label>Imágenes (hasta 5)</label>

      <input
        type="file"
        accept="image/*"
        multiple
        onChange={handleImagen}
      />

      {preview.length > 0 && (
        <div
          style={{
            display: "flex",
            gap: "12px",
            flexWrap: "wrap",
            marginBottom: "20px",
          }}
        >
          {preview.map((img, index) => (
            <img
              key={index}
              src={img}
              alt=""
              className="preview-image"
            />
          ))}
        </div>
      )}

      <label>Nombre</label>

      <input
        name="nombre"
        placeholder="Ej: Smart TV TCL 50"
        value={form.nombre}
        onChange={handleChange}
        required
      />

      <label>Categoría</label>

      <input
        name="categoria"
        placeholder="TV, Celulares, Cocina..."
        value={form.categoria}
        onChange={handleChange}
        required
      />
<label>💵 Moneda</label>

<select
  name="moneda"
  value={form.moneda}
  onChange={handleChange}
>
  <option value="ARS">🇦🇷 Pesos (ARS)</option>
  <option value="USD">🇺🇸 Dólares (USD)</option>
</select>
      <label>💰 Precio Unitario</label>

      <input
        type="number"
        name="precio"
        value={form.precio}
        onChange={handleChange}
        required
      />

      <label>🔥 Precio x2</label>

      <input
        type="number"
        name="precio2"
        value={form.precio2}
        onChange={handleChange}
      />

      <label>🔥 Precio x3</label>

      <input
        type="number"
        name="precio3"
        value={form.precio3}
        onChange={handleChange}
      />

      <label>🔥 Precio x6</label>

      <input
        type="number"
        name="precio6"
        value={form.precio6}
        onChange={handleChange}
      />

      <label>🔥 Precio x9</label>

      <input
        type="number"
        name="precio9"
        value={form.precio9}
        onChange={handleChange}
      />

      <label>🔥 Precio x12</label>

      <input
        type="number"
        name="precio12"
        value={form.precio12}
        onChange={handleChange}
      />

      <label>📦 Stock</label>

      <input
        type="number"
        name="stock"
        value={form.stock}
        onChange={handleChange}
      />

      <label>👁 Estado</label>

      <select
        name="visible"
        value={String(form.visible)}
        onChange={(e) =>
          setForm({
            ...form,
            visible: e.target.value === "true",
          })
        }
      >
        <option value="true">🟢 Visible</option>
        <option value="false">🔴 Oculto</option>
      </select>

      <label>Descripción</label>

      <textarea
        rows="5"
        name="descripcion"
        value={form.descripcion}
        onChange={handleChange}
      />

      <button type="submit">
        💾 {textoBoton}
      </button>

    </form>
  );
}