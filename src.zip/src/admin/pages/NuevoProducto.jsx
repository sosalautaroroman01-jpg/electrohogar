import { useNavigate } from "react-router-dom";

import Layout from "../components/Layout";
import ProductForm from "../components/ProductForm";

import { crearProducto } from "../../services/productosService";
import {
  subirImagen,
  subirImagenes,
} from "../../services/storageService";

export default function NuevoProducto() {
  const navigate = useNavigate();

  async function guardarProducto(data) {
    try {

      let imagen = "";
      let imagenes = [];

      // ✅ Nuevo sistema (varias imágenes)
      if (data.imagenesFile?.length) {

        imagenes = await subirImagenes(data.imagenesFile);

        imagen = imagenes[0];

      }

      // Compatibilidad con el sistema viejo
      else if (data.imagenFile) {

        imagen = await subirImagen(data.imagenFile);

        imagenes = [imagen];

      }

      await crearProducto({

  nombre: data.nombre,

  categoria: data.categoria,

  moneda: data.moneda,

  precio: Number(data.precio),

  precio2: data.precio2
    ? Number(data.precio2)
    : null,

  precio3: data.precio3
    ? Number(data.precio3)
    : null,

        precio6: data.precio6
          ? Number(data.precio6)
          : null,

        precio9: data.precio9
          ? Number(data.precio9)
          : null,

        precio12: data.precio12
          ? Number(data.precio12)
          : null,

        stock: data.stock
          ? Number(data.stock)
          : null,

        descripcion: data.descripcion,

        // Compatibilidad
        imagen,

        // Nuevo sistema
        imagenes,

        visible: data.visible,

        creado: new Date(),

      });

      alert("✅ Producto guardado correctamente");

      navigate("/admin/productos");

    } catch (error) {

      console.error(error);

      alert("❌ Error al guardar el producto");

    }
  }

  return (
    <Layout>
      <h1>➕ Nuevo Producto</h1>

      <ProductForm
        onSubmit={guardarProducto}
        textoBoton="Guardar Producto"
      />
    </Layout>
  );
}