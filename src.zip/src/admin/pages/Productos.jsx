import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import Layout from "../components/Layout";
import ProductTable from "../components/ProductTable";

import {
  escucharProductos,
  eliminarProducto,
  cambiarVisibilidad,
} from "../../services/productosService";

export default function Productos() {
  const [productos, setProductos] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [categoria, setCategoria] = useState("Todas");
  const [vista, setVista] = useState("publicados");

  const navigate = useNavigate();

  useEffect(() => {
  const unsubscribe = escucharProductos((data) => {
    console.log("🔥 Firebase devolvió:", data.length);
    setProductos(data);
  });

  return () => unsubscribe();
}, []);

  async function handleDelete(id) {
    if (!window.confirm("¿Eliminar producto?")) return;
    await eliminarProducto(id);
  }

  async function handleToggleVisible(producto) {
    try {
      await cambiarVisibilidad(producto.id, !producto.visible);
    } catch (error) {
      console.error(error);
      alert("Error al cambiar la visibilidad");
    }
  }

  const categorias = [
    "Todas",
    "Smart TV",
    "Aires",
    "Heladeras",
    "Lavarropas",
    "Cocina",
    "Accesorios de Cocina",
    "Calefacción",
    "Termotanques",
    "Pequeños Electros",
    "Belleza y Cuidado",
    "Audio",
    "Herramientas",
    "Celulares",
    "Hogar",
  ];

  const publicados = useMemo(() => {
    return productos.filter((p) => p.visible !== false);
  }, [productos]);

  const ocultos = useMemo(() => {
    return productos.filter((p) => p.visible === false);
  }, [productos]);

  const productosFiltrados = useMemo(() => {
    let lista;

    switch (vista) {
      case "publicados":
        lista = publicados;
        break;

      case "ocultos":
        lista = ocultos;
        break;

      default:
        lista = productos;
        break;
    }

    return lista.filter((producto) => {
      const coincideNombre = producto.nombre
        ?.toLowerCase()
        .includes(busqueda.toLowerCase());

      const coincideCategoria =
        categoria === "Todas" ||
        producto.categoria === categoria;

      return coincideNombre && coincideCategoria;
    });
  }, [
    vista,
    productos,
    publicados,
    ocultos,
    busqueda,
    categoria,
  ]);
console.log("=== RENDER PRODUCTOS ===");
console.log("productos", productos);
console.log("cantidad", productos.length);
console.log("publicados", publicados.length);
console.log("ocultos", ocultos.length);
console.log("filtrados", productosFiltrados.length);
      return (
    <Layout>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "25px",
        }}
      >
        <h1>📦 Productos ({productos.length})</h1>

        <button onClick={() => navigate("/admin/productos/nuevo")}>
          ➕ Nuevo Producto
        </button>
      </div>

      <div
        style={{
          display: "flex",
          gap: "15px",
          marginBottom: "25px",
          flexWrap: "wrap",
        }}
      >
        <input
          type="text"
          placeholder="🔍 Buscar producto..."
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
          style={{
            flex: 1,
            minWidth: "280px",
            padding: "12px",
            borderRadius: "10px",
            border: "1px solid #ddd",
          }}
        />

        <select
          value={categoria}
          onChange={(e) => setCategoria(e.target.value)}
          style={{
            padding: "12px",
            borderRadius: "10px",
            border: "1px solid #ddd",
          }}
        >
          {categorias.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>
      </div>

      <div
        style={{
          display: "flex",
          gap: "10px",
          marginBottom: "20px",
          flexWrap: "wrap",
        }}
      >
        <button
          onClick={() => setVista("publicados")}
          style={{
            padding: "10px 16px",
            borderRadius: "8px",
            border: "none",
            cursor: "pointer",
            background: vista === "publicados" ? "#16a34a" : "#e5e7eb",
            color: vista === "publicados" ? "#fff" : "#111",
            fontWeight: 600,
          }}
        >
          🟢 Publicados ({productos.length})
        </button>

        <button
          onClick={() => setVista("ocultos")}
          style={{
            padding: "10px 16px",
            borderRadius: "8px",
            border: "none",
            cursor: "pointer",
            background: vista === "ocultos" ? "#dc2626" : "#e5e7eb",
            color: vista === "ocultos" ? "#fff" : "#111",
            fontWeight: 600,
          }}
        >
          🚫 Hay que reponer ({ocultos.length})
        </button>

        <button
          onClick={() => setVista("todos")}
          style={{
            padding: "10px 16px",
            borderRadius: "8px",
            border: "none",
            cursor: "pointer",
            background: vista === "todos" ? "#2563eb" : "#e5e7eb",
            color: vista === "todos" ? "#fff" : "#111",
            fontWeight: 600,
          }}
        >
          📦 Todos ({publicados.length})
        </button>
      </div>

      <ProductTable
        productos={productosFiltrados}
        onDelete={handleDelete}
        onToggleVisible={handleToggleVisible}
      />
    </Layout>
  );
}