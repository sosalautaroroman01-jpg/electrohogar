import "./Categories.css";
import { useFilter } from "../context/FilterContext";

function Categories() {
  const {
    categoria,
    setCategoria,
    setBusqueda,
  } = useFilter();

  const categorias = [
    "Todas",
    "Smart TV",
    "Celulares",
    "Audio",
    "Entretenimiento",
    "Aires",
    "Heladeras",
    "Freezers",
    "Lavarropas",
    "Cocina",
    "Accesorios de Cocina",
    "Pequeños Electros",
    "Botellas y Térmicos",
    "Belleza y Cuidado",
    "Limpieza",
    "Jardín",
    "Calefacción",
    "Termotanques",
    "Herramientas",
    "Iluminación",
    "Cámaras de Seguridad",
    "Hogar",
  ];

  const iconos = {
    Todas: "🏠",
    "Smart TV": "📺",
    Celulares: "📱",
    Audio: "🔊",
    Entretenimiento: "🎮",
    Aires: "❄️",
    Heladeras: "🧊",
    Freezers: "🥶",
    Lavarropas: "🧺",
    Cocina: "🍳",
    "Accesorios de Cocina": "🍽️",
    "Pequeños Electros": "⚡",
    "Botellas y Térmicos": "🥤",
    "Belleza y Cuidado": "💇",
    Limpieza: "🧹",
    Jardín: "🌿",
    Calefacción: "🔥",
    Termotanques: "🚿",
    Herramientas: "🛠️",
    Iluminación: "💡",
    "Cámaras de Seguridad": "📹",
    Hogar: "🛋️",
  };

  function seleccionarCategoria(cat) {
    setBusqueda("");
    setCategoria(cat);
  }

  return (
    <div className="categories">
      {categorias.map((cat) => (
        <button
          key={cat}
          onClick={() => seleccionarCategoria(cat)}
          className={
            categoria === cat
              ? "category-btn active"
              : "category-btn"
          }
        >
          {iconos[cat]} {cat}
        </button>
      ))}
    </div>
  );
}

export default Categories;