import "./SearchBar.css";
import { useFilter } from "../context/FilterContext";

function SearchBar() {
  const {
    busqueda,
    setBusqueda,
    setCategoria,
  } = useFilter();

  function buscar(e) {
    setBusqueda(e.target.value);
    setCategoria("Todas");
  }

  return (
    <div className="search-container">
      <input
        type="text"
        placeholder="🔍 Buscar productos..."
        className="search-input"
        value={busqueda}
        onChange={buscar}
      />
    </div>
  );
}

export default SearchBar;