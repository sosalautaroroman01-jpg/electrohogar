import FloatingCart from "../components/FloatingCart";
import AnimatedBackground from "../components/AnimatedBackground";
import Header from "../components/Header";
import SearchBar from "../components/SearchBar";
import Categories from "../components/Categories";
import ProductGrid from "../components/ProductGrid";
import Cart from "../components/Cart";
import DollarTicker from "../components/DollarTicker";

function Home() {
  return (
    <>
      <AnimatedBackground />

      <Cart />
      <FloatingCart />

      <div className="app">

        <DollarTicker />

        <Header />

        <section className="hero">

          <div className="hero-search">
            <SearchBar />
          </div>

          <div className="hero-categories">
            <Categories />
          </div>

        </section>

        <section className="catalog-title">

          <h1>
            Equipá tu hogar con las mejores marcas
          </h1>

          <p>
            Más de <strong>600 productos</strong>
          </p>

        </section>

        <ProductGrid />

      </div>
    </>
  );
}

export default Home;