import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { storage } from "../firebase";

// Subir una sola imagen (compatibilidad)
export async function subirImagen(file) {
  if (!file) return "";

  const nombre = `${Date.now()}-${file.name}`;
  const referencia = ref(storage, `productos/${nombre}`);

  await uploadBytes(referencia, file);

  return await getDownloadURL(referencia);
}

// ✅ Subir varias imágenes
export async function subirImagenes(files) {

  if (!files || files.length === 0) return [];

  const urls = [];

  for (const file of files) {

    const nombre = `${Date.now()}-${Math.random()}-${file.name}`;

    const referencia = ref(storage, `productos/${nombre}`);

    await uploadBytes(referencia, file);

    const url = await getDownloadURL(referencia);

    urls.push(url);

  }

  return urls;
}